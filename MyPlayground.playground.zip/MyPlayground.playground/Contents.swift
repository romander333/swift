import Cocoa

struct Meal {
    var name: String
    var calories: Int?
    var type: String?
    
    static func describe(meal: Meal) {
        let calText = meal.calories ?? 0 > 0 ? "\(meal.calories!) калорій" : "Калорійність невідома"
        let typeText = meal.type ?? "Not found type meal"
        
        print("Meal: \(meal.name), \(calText), \(typeText)")
    }
}
    
    
    func describeMeal(meal: Meal) {
        let calText = meal.calories != nil ? "\(meal.calories!) калорій" : "Калорійність невідома"
        let typeText = meal.type ?? "Not found type meal"
        
        print("Meal: \(meal.name), \(calText), \(typeText)")
    }

    
    var meals: [Meal] = [
    Meal(name: "Potato", calories: 100, type: "solder"),
    Meal(name: "Soup", calories: 250, type: "solder"),
    Meal(name: "Pasta", calories: 400, type: "solder")
    ]
    
    describeMeal(meal: meals[0])


class Chef {
    var name: String
    var bestDish: Meal
    
    init(name: String, bestDish: Meal) {
        self.name = name
        self.bestDish = bestDish
    }
    
    
    func outputBestChefDish(chef: Chef) {
        print("Dish:  \(name)")
        print(describeMeal(meal: bestDish))
    }
}

enum MealType {
    case breakfast
    case lunch
    case dinner
}



