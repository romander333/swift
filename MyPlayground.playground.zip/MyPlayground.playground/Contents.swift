import Cocoa

struct Meal {
    var name: String
    var calories: Int?
    var type: MealType
    
    static func describe(meal: Meal) {
        let calText = (meal.calories ?? 0) > 0 ? "\(meal.calories!) калорій" : "Калорійність невідома"
        let typeText = meal.type.rawValue
        
        print("Meal: \(meal.name), \(calText), \(typeText)")
    }
}
    
    
    func describeMeal(meal: Meal) {
        let calText = meal.calories != nil ? "\(meal.calories!) калорій" : "Калорійність невідома"
        let typeText = meal.type.rawValue
        
        print("Meal: \(meal.name), \(calText), \(typeText)")
    }


func sumOfCalories(meals: [Meal]) {
    var sumCalories: Int = 0
    
    for meal in meals {
        if let calories = meal.calories, calories > 0 {
            sumCalories += calories
        }
    }
    
    print("Sum of calories: \(sumCalories)")
}


    var meals: [Meal] = [
        Meal(name: "Potato", calories: 100, type: .lunch),
        Meal(name: "Soup", calories: 250, type: .dinner),
        Meal(name: "Pasta", calories: 400, type: .breakfast)
    ]
    
    describeMeal(meal: meals[2])

sumOfCalories(meals: meals)


class Chef {
    var name: String
    var bestDish: Meal
    
    init(name: String, bestDish: Meal) {
        self.name = name
        self.bestDish = bestDish
    }
    
    
    func outputBestChefDish(chef: Chef) {
        print("Dish: \(name)")
        print(describeMeal(meal: bestDish))
    }
}



enum MealType: String {
    case breakfast = "The main food of the day"
    case lunch
    case dinner
}



